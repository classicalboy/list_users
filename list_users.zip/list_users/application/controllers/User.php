<?php


class User extends CI_Controller {


		
	public function __construct() {
	    parent::__construct();
	    $this->load->model('user_model');
	  }
	
	public function index()
	{
		$allUsers = $this->user_model->get_all_users();
		$data = array();
		$data['users'] = $allUsers;
		$this->load->helper('url'); 
		$this->load->view('users', $data);
	}

	public function register(){
		$data = $_REQUEST;
		$success = $this->user_model->insert($data);
		echo json_encode(array('success'=>$success));
	}

	public function get_user_detail(){
		$userId = $this->input->get('recordid');
		$detail = $this->user_model->fetch_detail($userId);
		echo json_encode($detail);
	}

	public function update($id){
		$success = false;
		if(!empty($id)){
			$data = $_REQUEST;
			$success = $this->user_model->update($id, $data);
		}
		echo json_encode(array('success'=>$success));
	}

	public function remove($id){
		$success = false;
		if(!empty($id)){
			$data = ["active"=>0];
			$success = $this->user_model->update($id, $data);
		}
		echo json_encode(array('success'=>$success));
	}

}
?>