<?php
	include 'header.php';
// there are built-in codeigniter functions that can also be used to render a form
?>

<h3>Users' List</h3>
		<table class="table table-hover">
			<thead>
		      <tr>
		        <th>User Name</th>
		        <th>Email</th>
		        <th>Actions</th>
		      </tr>
		    </thead>
    	<tbody>
		<?php 
			foreach($users as $id=>$user) {
				echo "<tr><td data-id=".$id." data-toggle='modal' data-target='#viewDetail'>".$user['name']."</td><td>".$user['email']."</td><td><button type='button' class='btn btn-info' data-id=".$id." data-toggle='modal' data-target='#viewDetail'>view</button></td></tr>";
			} 
		?>
		</tbody>
		</table>
		
	</div>
	<div class="modal fade" id="viewDetail" role="dialog">
	<div class="modal-dialog">
		
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal">&times;</button>
          		<h4 class="modal-title">Details</h4>
			</div>
			<div class="modal-body">
			<div class="alert" role="alert" id="msg"></div>
			<span id="userId" value="" hidden=""></span>
          		<form role="form" action="user/update" id="updateForm" method="post">
            		<div class="form-group">
              			<label for="usrname"><span class="glyphicon glyphicon-user"></span> Username</label>
              			<input type="text" class="form-control" id="usrname" value="" placeholder="Enter Name" required>
            		</div>
            		<div class="form-group">
              			<label for="email"><span class="glyphicon glyphicon-email"></span> Email Id</label>
              			<input type="email" class="form-control" id="email" value="" placeholder="Enter Email" required>
            		</div>
            		<div class="form-group">
              			<label for="mobile"><span class="glyphicon glyphicon-mobile"></span> Mobile </label>
              			<input type="text" class="form-control" id="mobile" value="" placeholder="Enter Mobile Number" min="10" max="10" required>
            		</div>
            		<div class="form-group">
              			<label for="address"><span class="glyphicon glyphicon-address"></span> Mobile </label>
              			<textarea  class="form-control" id="address" value="" placeholder="Enter Address" required></textarea>
            		</div>
            		<button type="submit" class="btn btn-success btn-block"><span class="glyphicon glyphicon-off"></span> Update</button>
            	</form>
        	</div>
        	<div class="modal-footer">

          		<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
       		</div>
		</div>
	</div>
</div>
	<p class="footer">Page rendered in <strong>{elapsed_time}</strong> seconds. <?php echo  (ENVIRONMENT === 'development') ?  'CodeIgniter Version <strong>' . CI_VERSION . '</strong>' : '' ?></p>
</div>
<script type="text/javascript">
	
	$(document).ready(function(){
	    $('#viewDetail').on('show.bs.modal', function (e) {
	        var recordid = $(e.relatedTarget).data('id');

	        $.ajax({
	            type : 'get',
	            url : 'user/get_user_detail', //Here you will fetch records 
	            data :  'recordid='+ recordid, //Pass $id
	            complete: function(){
	            		$('#updateForm').show();
            			$('#msg').hide();
	            },
	            success : function(data){
	            	data = JSON.parse(data);
	            	$('#usrname').val(data.name);
	            	$('#email').val(data.email);
	            	$('#mobile').val(data.mobile);
	            	$('#address').val(data.address);
	            	$('#userId').val(recordid);
	            },
	            error: function (data) {
	            	// body...
	            	console.log(data);
	            	$('#updateForm').hide();
	            	$('#msg').html("There is some error. Please contact support.");
            		$('#msg').show();
	            }
	        });

	     });

	$('#updateForm').on('submit', function(e) {
            e.preventDefault();
            var id = $('#userId').val();
            $.ajax({
            	type: 'POST',
            	url: 'user/update/' + id,
            	data: {
            		name: $('#usrname').val(),
            		email: $('#email').val(),
            		mobile: $('#mobile').val(),
            		address: $('#address').val()
            	},
            	complete: function (response){
            		$('#updateForm').hide();
            		$('#msg').show();
            	},
            	success: function (response) {
            		response = JSON.parse(response);
            		if(response.success){
            			$('#msg').html("User detials have been updated!");
            			$('#msg').removeClass("alert-danger");
            			$('#msg').addClass("alert-info");
            		} else{
            			$('#msg').html("User detials could not be updated! Please contact support.");
            			$('#msg').removeClass("alert-info");
            			$('#msg').addClass("alert-danger");
            		}
            	},
            	error: function (error){
            		console.log(error);
            		$('#msg').html("User detials could not be submitted! Please contact support.");
            		$('#msg').removeClass("alert-info");
            		$('#msg').addClass("alert-danger");
            	},
            });
        });
});
</script>
</body>
</html>