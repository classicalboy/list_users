<?php
	include 'header.php';
// there are built-in codeigniter functions that can also be used to render a form
?>
<div clas="row"><div class="col-md-4">
<h3 style="color:#8b4513">Registered Users</h3></div>
<div class="col-md-6"><a style="float: right" href="" data-id="" data-toggle='modal' data-target='#viewDetail'>Register A User</a></div></div>
<div clas="row"><div class="col-md-12">
<hr></div></div>
		<table class="table table-hover" style="width: 95%">
			<thead>
		      <tr>
		        <th style="font-size: 20px">User Name</th>
		        <th style="font-size: 20px">Email</th>
		        <th style="font-size: 20px">Actions</th>
		      </tr>
		    </thead>
    	<tbody>
		<?php 
            if(empty($users[0])){
                echo "<tr><td style='font-size: 20px; color:darkblue;text-align: center;'>There are no registered user!</td></tr>";
            } else{
                foreach($users as $id=>$user) {
                    echo "<tr><td>".$user->name."</td><td>".$user->email."</td><td><button type='button' class='btn btn-info' style='margin: 2px;font-size:13px' data-id=".$user->id." data-toggle='modal' data-target='#viewDetail'>View/Edit</button><button type='button' class='btn btn-danger' id='deleteUserBtn' onclick='deleteUser(".$user->id.",\"".$user->name."\")' style='margin: 2px;font-size:13px'>Delete</button></td></tr>";
                }
            }
		?>
		</tbody>
		</table>
		
	</div>
	<?php include_once 'ModalPopup.php'; ?>
</div>
	<p class="footer">Page rendered in <strong>{elapsed_time}</strong> seconds. <?php echo  (ENVIRONMENT === 'development') ?  'CodeIgniter Version <strong>' . CI_VERSION . '</strong>' : '' ?></p>
</div>
<script type="text/javascript">
	var modalAction = "";
    function deleteUser(Id, Name){
            var c = confirm("Are you sure to delete the user "+ Name);
            if(c && Id){
                $.ajax({
                    type: 'get',
                    url: 'user/remove' + "/" + Id,
                    success: function(response){
                        console.log(response);
                        alert(Name + " user deleted successfully!");
                        location.reload();
                    },
                    error: function(response){
                        console.log(response);
                        alert("Some error occured! Please contact support.");
                    }

                });
            }
        };

	$(document).ready(function(){
       $('#viewDetail').on('show.bs.modal', function (e) {
	        var recordid = $(e.relatedTarget).data('id');
            var url = "";
            var data = "";
            $('#modalFormButton').attr('action', 'user/register');
            if(recordid){
                        $('#modalFormButton').html("Update");
                        $('#modalFormButton').attr('action', 'user/update');
                        url = "user/get_user_detail";
                        data = 'recordid='+ recordid;
                        $.ajax({
                        type : 'get',
                        url : url, //Here you will fetch records 
                        data :  data,//Pass $id
                        complete: function(){
                                $('#updateForm').show();
                                $('#msg').hide();
                        },
                        success : function(data){
                            data = JSON.parse(data);
                            modalAction = "view";
                            console.log(data);
                                $('#usrname').val(data[0].name);
                                $('#email').val(data[0].email);
                                $('#mobile').val(data[0].mobile);
                                $('#address').val(data[0].address);
                                $('#userId').val(recordid);
                        },
                        error: function (data) {
                            console.log(data);
                            $('#updateForm').hide();
                            $('#userId').val('');
                            $('#msg').html("There is some error. Please contact support.");
                            $('#msg').show();
                        }
                    });
                } else{
                    $('#modalFormButton').html("Register");
                    $('#userId').val('');
                }
	     });
        $("#viewDetail").on('hidden.bs.modal',function modalClose(e) {
            $('#msg').hide();
            $('#updateForm').show();
            if(modalAction == "update"){
                location.reload();
            }
        })

	$('#updateForm').on('submit', function(e) {
            e.preventDefault();
            var id = $('#userId').val();
            var action = $('#modalFormButton').attr('action');
            if(id){
                action = action + '/' + id;
            }
            $.ajax({
            	type: 'POST',
            	url: action,
            	data: {
            		name: $('#usrname').val(),
            		email: $('#email').val(),
            		mobile: $('#mobile').val(),
            		address: $('#address').val()
            	},
            	complete: function (response){
            		$('#updateForm').hide();
            		$('#msg').show();
            	},
            	success: function (response) {
                    modalAction = "update";
            		response = JSON.parse(response);
                    console.log(response);
            		if(response.success){
                        var msg = "User reigstered successfully."
                        if(id){
                            msg = "User detials have been updated!";
                        }
            			$('#msg').html(msg);
            			$('#msg').removeClass("alert-danger");
            			$('#msg').addClass("alert-info");
            		} else{
            			$('#msg').html("User detials could not be updated! Please contact support.");
            			$('#msg').removeClass("alert-info");
            			$('#msg').addClass("alert-danger");
            		}
            	},
            	error: function (error){
            		console.log(error);
            		$('#msg').html("User detials could not be submitted! Please contact support.");
            		$('#msg').removeClass("alert-info");
            		$('#msg').addClass("alert-danger");
            	},
            });
        });
});
</script>
</body>
</html>