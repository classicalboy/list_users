<?php
	include 'header.php';
?>
	<div class="row" id="welcome" style="margin: auto; width: 500px; height: 500px; display: block;
		">
		<div class="col-md-12">
			<h3>WELCOME TO USER APP<hr> PLEASE SELECT A MENU FROM ABOVE</h3>
		</div>
	</div>
<?php 
include 'footer.php';
 ?>