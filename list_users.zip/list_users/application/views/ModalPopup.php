<div class="modal fade" id="viewDetail" role="dialog">
	   <div class="modal-dialog">
		    <div class="modal-content">
			     <div class="modal-header">
				    <button type="button" class="close" data-dismiss="modal">&times;</button>
          		 <h4 class="modal-title">Details</h4>
			</div>
			<div class="modal-body">
			     <div class="alert" role="alert" id="msg"></div>
			     <span id="userId" value="" hidden=""></span>
          		 <form role="form" id="updateForm" method="post">
            		<div class="form-group">
              			<label for="usrname"><span class="glyphicon glyphicon-user"></span> Username</label>
              			<input type="text" class="form-control" id="usrname" value="" placeholder="Enter Name" required>
            		</div>
            		<div class="form-group">
              			<label for="email"><span class="glyphicon glyphicon-email"></span> Email Id</label>
              			<input type="email" class="form-control" id="email" value="" placeholder="Enter Email" required>
            		</div>
            		<div class="form-group">
              			<label for="mobile"><span class="glyphicon glyphicon-mobile"></span> Mobile </label>
              			<input type="text" class="form-control" id="mobile" value="" placeholder="Enter Mobile Number" min="10" max="10" required>
            		</div>
            		<div class="form-group">
              			<label for="address"><span class="glyphicon glyphicon-address"></span> Mobile </label>
              			<textarea  class="form-control" id="address" value="" placeholder="Enter Address" required></textarea>
            		</div>
            		<button type="submit" class="btn btn-success btn-block"><span class="glyphicon glyphicon-off" id="modalFormButton"></span></button>
            	    </form>
        	</div>
        	<div class="modal-footer">
          		<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
       		</div>
		</div>
	</div>