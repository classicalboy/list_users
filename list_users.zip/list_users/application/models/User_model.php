<?php

	class User_model extends CI_Model{



		static $USERS = [
				  'id_1'=>[
					'name' => 'Vipin',
					'email' => 'vipin.kaus29@outlook.com',
					'mobile' => '8742984800',
					'address' => 'Sec 46, Gurgaon'
				],
				'id_2'=>[
					'name' => 'Vipin',
					'email' => 'vipin.kaus29@outlook.com',
					'mobile' => '8742984800',
					'address' => 'Sec 46, Gurgaon'
					]
				];


		 public function __construct() { 
	         parent::__construct(); 
	      } 

	      public function get_all_users(){
	      	// in actual environment it will fetch from a database using built-in codeigniter functions
	      	return self::$USERS;

	      }

	      public function fetch_detail($id){
	      	if(isset(self::$USERS[$id])){
	      		return self::$USERS[$id];
	      	}
	      	else {
	      		return array();
	      	}
	      }

	      public function update($id, $data){
	      	//server side validation can be done using a helper class
	      	try{
	         	 foreach ($data as $key => $value) {
		      	 	self::$USERS[$id][$key] = $value; 
		      	 }
		      	 $status = self::$USERS;
		      	}
		      	catch(Exception $e){
		      		$status = false;
		      	}
	      	 return $status;
	      }

	}

?>